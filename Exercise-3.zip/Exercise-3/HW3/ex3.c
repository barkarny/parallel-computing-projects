#include <stdio.h>
#include <omp.h>
#include <math.h>
#include <stdlib.h>
#include <mpi.h>
#include <ctime>
#include <cstdlib>
#include "myProto.h"

int main(int argc, char **argv)
{
	int rank, size;
	MPI_Status status ; 
	int* array;
	srand(time(NULL));
	
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    	MPI_Comm_size(MPI_COMM_WORLD, &size);	
	
	
    	// Check that there is exactly two proceeses
	 if (size != 2) 
		 MPI_Abort(MPI_COMM_WORLD, 0);

    	//master
    	if(rank == 0){
        	array = (int*)malloc(sizeof(int)*(PART*4));
        	if(!array){
            		printf("Error : dinamic allocate failed");
        }
        //Putting values in array
	#pragma omp paralle for
		for (int i = 0 ; i < PART*4 ; i++){
			array[i] = rand() % 255;
             } 
		// send half pf the arrat to P1
        	MPI_Send(&array[PART*2] , PART*2 , MPI_INT , 1 , 0 , MPI_COMM_WORLD);

    	}

    else{

        array = (int*)malloc(sizeof(int)*(PART*2));  
        if(!array){
            printf("Error : dinamic allocate failed");
        }
        MPI_Recv(array , PART*2 , MPI_INT , 0 , 0 ,MPI_COMM_WORLD ,&status);
    }
    
    // 2 processes do this
    //Temporary array that will contain the results from cuda and openmp - 2 hist
    int* temp_hist = (int*)calloc(RANGE*2, sizeof(int));
    if(!temp_hist){
    	printf("Error : dinamic allocate failed");
    }
    
    
    // On each process - second PART of the Temporary array works with CUDA
    if (computeOnGPU(array + PART, PART , temp_hist+RANGE ) != 0)
       MPI_Abort(MPI_COMM_WORLD, __LINE__);


// OPENMP - for each thread we alocate temp hist in order to prevent race condition 
	int* thread_temp = (int*)calloc(4*RANGE , sizeof(int));
	if(!thread_temp){
    		printf("Error : dinamic allocate failed");
    	}
	int tid = 0 ;
	int val = 0 ;
#pragma omp parallel num_threads(4) private (tid , val)
{	
	int tid = omp_get_thread_num();	
#pragma omp for
	for (int i = 0 ; i < PART ; i++){
		val = array[i];
		thread_temp[tid*RANGE + val]++;
	}
	
	val = 0 ;
#pragma omp for // 4 threads Gather the results to temp hist
	for (int i = 0 ; i < RANGE ; i++){
		for(int j = 0 ; j < 4 ; j ++){
			val += thread_temp[i + j*RANGE];			
		}
		temp_hist[i] = val;
		val = 0 ;
	}
	
}	
	
	// each process gather its cuda_hist and openmp_hist to 1 hist
	int* process_hist = (int*)calloc(RANGE , sizeof(int));
	if(!process_hist){
    		printf("Error : dinamic allocate failed");
    	}	
    	unify_2_hist(temp_hist , temp_hist + RANGE , RANGE , process_hist); 
    	free(thread_temp);
    	free(temp_hist);

    // PROCESS 1 send his hist to process 0
    if (rank == 1){
    	MPI_Send(process_hist, RANGE, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }
    else{  //MASTER     	
    	int* process_1_hist = (int*)calloc(RANGE , sizeof(int));
    	int* final_hist = (int*)calloc(RANGE , sizeof(int));
 	if(!process_1_hist || !final_hist){
    		printf("Error : dinamic allocate failed");
    	}   	   
        MPI_Recv(process_1_hist, RANGE, MPI_INT, 1, 0, MPI_COMM_WORLD, &status);
        //unify hist of each process to --> 1 hist
	unify_2_hist(process_hist, process_1_hist, RANGE , final_hist); 	
	histTest(final_hist , RANGE , PART*4);		
	//showHist(final_hist , RANGE);
	free(final_hist);   
    }
 	MPI_Finalize();
	return 0;
	
}


