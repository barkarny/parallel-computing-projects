#pragma once
 
#define PART 20000
#define RANGE 256

void histTest(int* hist , int size , int numElements);
int unify_2_hist(int* a , int* b , int numElements , int* hist); 
void showHist(int* hist , int size);
int computeOnGPU(int* data, int numElements , int* hist);
