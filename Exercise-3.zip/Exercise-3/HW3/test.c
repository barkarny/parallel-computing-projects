#include <stdio.h>
#include "myProto.h"

void histTest(int* hist , int size , int numElements){
	
	int sum = 0 ; 
	for (int i = 0 ; i < size ; i ++){
		sum += hist[i];
	}
	
	if(sum != numElements){
		printf("Error : hist Test failed");

	}
	printf("hist Test passed successfully\n"); 


}

int unify_2_hist(int* a , int* b , int numElements , int* hist){
	for(int i = 0 ; i < numElements ; i++){
		hist[i] = a[i]+ b[i];
	}

	return 0;
}

void showHist(int* hist ,int size){
	for(int i = 0 ; i < size ; i++){
		printf("hist[%d] : %d\n", i , hist[i] );
	}
}

