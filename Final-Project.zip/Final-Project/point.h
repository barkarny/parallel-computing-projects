#pragma once
 
typedef struct {
    int id;
    double x1 ;
    double x2 ;
    double a ;
    double b ;
    int satisfy ;
    double X ; 
    double Y;
    int k;

} Point;

void coord_cal(double x1 , double x2 , double a ,double b ,double t, double* X , double* Y);
void coord(Point* p , double t);

