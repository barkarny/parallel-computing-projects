#pragma once

#include "point.h"
#include "result.h"

double distance_cal(Point* p1 , Point* p2);
void t_cal(double* arr , int tcount);
void init_k (Point* arr , int size);
void coord_cal_for_array_of_points(Point* arr , int size , double t);
int computeOnGPU(double* t_arr, int num_elements , Point* points , int list_size , Result* result , int K , double distance);

