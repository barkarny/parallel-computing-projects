#include <mpi.h>
#include <stdio.h>
#include <omp.h>
#include <stdlib.h>

#include "point.h"
#include "functions.h"
#include "result.h"

/*
 MPI+OpenMP+CUDA Integration 
Process 0  - Master - read the input file . send all points to Slaves and the other parameter(K , distance ect.)
Mater calculate the t , and divide work on the t arr .
Every process gets a chank of 2 part - 1 for the openmp and the 2 the cuda
After calculating Master gather the results - and print int to an output.txt

*/
 

int main(int argc, char *argv[]) {
    int size, rank;
    int list_size , K ;
    double distance;
    double* t_2part_arr;
    double* t_arr;
    int part;
    Point* points;
    Result* final_res ;
    int reminder; 
    MPI_Status  status;


    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    //Master read the file -- > calculate t_arr -- > reads all point into points arr
   if (rank == 0) 
   {
      int TCount;
      FILE* file;
      file = fopen("input.txt" , "r");
      if(!file){
         printf("Error opening the file");
         return 1;
      }
      fscanf(file, "%d", &list_size);
      fscanf(file, "%d", &K);
      fscanf(file, "%lf", &distance);
      fscanf(file, "%d", &TCount);

      // Calculate t
      t_arr = (double*)malloc(sizeof(double)*(TCount+1)); 
      if(!t_arr){
         printf("Error : malloc failed");
         fclose(file);
         return 1 ;
      }
      t_cal(t_arr , TCount);

      //Reading the points from the file into array
      points = (Point*)malloc(list_size*sizeof(Point));
      if(!points){
         printf("Error : points allocation failed");
         fclose(file);
         return 1;
      }

      for(int i = 0 ; i < list_size ; i++){
         fscanf(file , "%d %lf %lf %lf %lf" , &points[i].id , &points[i].x1 , &points[i].x2 , &points[i].a , &points[i].b );
      }

      // Close file after reading
      fclose(file);

      part = (TCount / size) / 2 ;
      reminder = TCount - 2*part*size ; 

   } 
   //Master broadcast list_size(number of points) , K , distance , and part to slaves
   MPI_Bcast(&list_size , 1 , MPI_INT , 0 , MPI_COMM_WORLD );
   MPI_Bcast(&K , 1 , MPI_INT , 0 , MPI_COMM_WORLD );
   MPI_Bcast(&distance , 1 , MPI_DOUBLE, 0 , MPI_COMM_WORLD );
   MPI_Bcast(&part , 1 , MPI_INT , 0 , MPI_COMM_WORLD );
   
   if(rank != 0) {
      points = (Point*)malloc(list_size*sizeof(Point));
      if(!points){
         printf("Error :  allocation failed");
         return 1;
      }
    }
   t_2part_arr = (double*)malloc(sizeof(double)*(2*part)); 
   //Master broadcast points array to slaves and divides t_arr so each process get different chunk 
   MPI_Bcast(points , sizeof(Point) * list_size , MPI_BYTE , 0 , MPI_COMM_WORLD);
   MPI_Scatter(t_arr, 2*part , MPI_DOUBLE , t_2part_arr , 2*part , MPI_DOUBLE , 0 , MPI_COMM_WORLD);
   
   
   // All processes will save the result in a temp array
   Result* pres = (Result*)malloc(sizeof(Result)*2*part);
   if(!pres)
   {
      printf("Error : allocation failed");
      return 1;
   } 

int tid;
#pragma omp parallel for shared(pres) firstprivate(points) private(tid)
//every thread catch entry in the t_2part_arr
   for(int i = 0 ; i < part ; i ++)
   {//for each t :
      int num_satisfy = 0 ; 
      tid = omp_get_thread_num();
      coord_cal_for_array_of_points(points , list_size , t_2part_arr[i]);
      init_k(points, list_size); 
      while(num_satisfy < 4 )
      {
         for (int j = 0 ; j < list_size ; j ++)
         {// for each point
               for (int q = j+1 ; q < list_size ; q ++)
               { // for each point that greater then j
                  if( distance > distance_cal(&points[j] , &points[q]))
                  { // distance between points is smaller then critira
                     points[j].k++;
                     points[q].k++;
                     if(points[j].k == K )
                     {
                        points[j].satisfy = 1 ;
                        pres[i].id_arr[num_satisfy] = points[j].id;
                        num_satisfy++;
                           
                     }
                     if(points[q].k == K )
                     {
                        points[q].satisfy = 1 ;
                        pres[i].id_arr[num_satisfy] = points[q].id;
                        num_satisfy++;
                     }
                     if(num_satisfy == 3){
                        pres[i].satisfy = 1 ;
                     }
                  }

               }
         }
         break;
      }
   }




   // On each process - perform a second half of its task with CUDA
    if (computeOnGPU(t_2part_arr + part, part , points , list_size , pres + part , K , distance) != 0)
       MPI_Abort(MPI_COMM_WORLD, __LINE__);

   

   if(rank == 0 )
   {

      final_res = (Result*)malloc(sizeof(Result) * (2*part*size + reminder)); 
      if(!final_res){
         printf("Error :  allocation failed");
         return 1 ;
      }
      
      if(reminder != 0 ){
         if (computeOnGPU(t_2part_arr + 2*part*size, reminder , points , list_size , pres + 2*part*size + reminder , K , distance) != 0)
            MPI_Abort(MPI_COMM_WORLD, __LINE__);        
      }

   }

   MPI_Barrier(MPI_COMM_WORLD);
   MPI_Gather(pres , sizeof(Result)*2*part , MPI_BYTE , final_res ,sizeof(Result)*2*part ,MPI_BYTE, 0 , MPI_COMM_WORLD );
   MPI_Barrier(MPI_COMM_WORLD);




 //Master writes the results to an output file
   if(rank == 0 )
   {

      FILE* file;
      file = fopen("output.txt" , "w");
      if(!file){
         printf("Error opening the file");
         return 1;
      }
      int satisfy_any_t = 0;
      for(int i = 0 ; i < 2*part*size + reminder; i ++)
      {
         if(final_res[i].satisfy == 1)
         {
            fprintf(file , "Points pointID%d pointID%d pointID%d satisfy Proximity Criteira as t = t%d \n" , final_res[i].id_arr[0] , final_res[i].id_arr[1] , final_res[i].id_arr[2] ,i );
            if(satisfy_any_t == 0 ){
               satisfy_any_t = 1 ;
            }
         }
      }
      if(satisfy_any_t == 0 )
      {
         fprintf(file ,"There were no 3 points found for any t");
      }

      fclose(file);
   }

    MPI_Finalize();
    return 0;
}

