#pragma once

typedef struct {
    int id_arr[3];
    int satisfy ;
} Result;
