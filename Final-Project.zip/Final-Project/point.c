#include "point.h"
#include <math.h>

void coord_cal(double x1 , double x2 , double a ,double b , double t, double* X , double* Y){

    *X = ((x2 - x1) / 2 ) * sin(t*M_PI/2 ) + (x2 + x1) / 2;
    *Y = a*(*X) + b;
}

void coord(Point* p , double t){

    p->X = ((p->x2 - p->x1) / 2 ) * sin(t*M_PI/2 ) + (p->x2 + p->x1) / 2;
    p->Y = p->a*(p->X) + p->b;
}
