#include "functions.h"
#include "point.h"
#include <math.h>
#include <stdio.h>

double distance_cal(Point* p1 , Point* p2)
{
    return sqrt(pow((p1->X - p2->X) , 2 ) + pow((p1->Y - p2->Y) , 2 ));
}
void t_cal(double* arr , int tcount)
{
    for (int i = 0 ; i < tcount + 1; i ++){
        arr[i] = (2.0 * i/tcount ) - 1 ;
        //printf("t[%i] = %lf\n" , i , arr[i]);
    }
}

void init_k (Point* arr , int size)
{
    for ( int i = 0 ; i < size ; i++)
        arr[i].k = 0;
    
}
void coord_cal_for_array_of_points(Point* arr , int size , double t)
{
    for(int i = 0 ; i < size ; i++)
        coord(&arr[i] , t);
}